"use client"

import React, { useState, useEffect } from "react"
import Link from "next/link"
import { Lock, Wallet, Loader2, AlertCircle } from "lucide-react"
import { unlockArticleWithWallet, getCurrentUser } from "./actions"
import { cn } from "@qoe/utils"

interface PaywallCutProps {
  contentHtml: string;
  isPremium: boolean;
  name: string | null;
  isBrutalist: boolean;
  accentColor: string | null;
  mainAppUrl: string;
  creatorId: string;
}

export function PaywallCut({ 
  contentHtml, 
  isPremium, 
  name, 
  isBrutalist, 
  accentColor,
  mainAppUrl,
  creatorId
}: PaywallCutProps) {
  // If not premium, render full content
  if (!isPremium) {
    return <div dangerouslySetInnerHTML={{ __html: contentHtml }} />;
  }

  // Find the paywall divider
  const paywallIndex = contentHtml.indexOf('<div data-type="paywall-divider"></div>');
  
  // If premium but no divider found, fallback to old behavior (cut at 30%)
  if (paywallIndex === -1) {
    const truncateIndex = Math.floor(contentHtml.length * 0.3);
    const truncatedContent = contentHtml.substring(0, truncateIndex) + '<p>...</p>';
    
    return (
      <>
        <div dangerouslySetInnerHTML={{ __html: truncatedContent }} />
        <PaywallOverlay 
          name={name} 
          isBrutalist={isBrutalist} 
          accentColor={accentColor} 
          mainAppUrl={mainAppUrl}
          creatorId={creatorId}
        />
      </>
    );
  }

  // Split content at the paywall
  const freeContent = contentHtml.substring(0, paywallIndex);

  return (
    <>
      <div dangerouslySetInnerHTML={{ __html: freeContent }} />
      <PaywallOverlay 
        name={name} 
        isBrutalist={isBrutalist} 
        accentColor={accentColor} 
        mainAppUrl={mainAppUrl}
        creatorId={creatorId}
      />
    </>
  );
}

function PaywallOverlay({ 
  name, 
  isBrutalist, 
  accentColor,
  mainAppUrl,
  creatorId
}: { 
  name: string|null, 
  isBrutalist: boolean, 
  accentColor: string|null,
  mainAppUrl: string,
  creatorId: string
}) {
  const [user, setUser] = useState<any>(null)
  const [loadingUser, setLoadingUser] = useState(true)
  const [unlocking, setUnlocking] = useState(false)
  const [errorMessage, setErrorMessage] = useState<string | null>(null)

  useEffect(() => {
    getCurrentUser().then((res: any) => {
      setUser(res)
      setLoadingUser(false)
    }).catch(() => {
      setLoadingUser(false)
    })
  }, [])

  const handleUnlock = async () => {
    if (!user) {
      // Redirect to login page on the main app
      window.location.href = `${mainAppUrl}/login?redirect=${encodeURIComponent(window.location.href)}`
      return
    }

    setUnlocking(true)
    setErrorMessage(null)

    try {
      const res = await unlockArticleWithWallet(creatorId, 200) // 2.00 € = 200 cents
      if (res.success) {
        // Reload to reveal full content
        window.location.reload()
      } else {
        if (res.error === "INSUFFICIENT_FUNDS") {
          setErrorMessage("Solde insuffisant dans votre portefeuille. Veuillez recharger votre compte sur l'application principale.")
        } else {
          setErrorMessage("Une erreur est survenue lors du paiement. Veuillez réessayer.")
        }
      }
    } catch (err) {
      console.error(err)
      setErrorMessage("Erreur réseau. Impossible de contacter le serveur de paiement.")
    } finally {
      setUnlocking(false)
    }
  }

  return (
    <div className="relative mt-8 w-full">
      <div className="absolute -top-32 left-0 w-full h-32 bg-gradient-to-t from-background to-transparent pointer-events-none" />
      <div className={`p-8 md:p-12 mx-auto max-w-2xl text-center not-prose relative z-10 ${isBrutalist ? 'bg-background border-4 border-foreground shadow-[8px_8px_0px_0px_rgba(0,0,0,1)]' : 'bg-card border border-neutral-200/80 dark:border-zinc-800/80 rounded-3xl shadow-2xl'}`}>
        <div className="w-16 h-16 rounded-full bg-[var(--tenant-accent)]/10 text-[var(--tenant-accent)] flex items-center justify-center mx-auto mb-6">
          <Lock className="w-8 h-8" />
        </div>
        <h3 className={`text-2xl md:text-3xl mb-4 ${isBrutalist ? 'font-black uppercase' : 'font-bold'}`}>Histoire Premium</h3>
        <p className="text-muted-foreground mb-8 text-lg">
          La suite de cette publication est exclusivement réservée aux abonnés de <strong className="text-foreground">{name}</strong>.
        </p>

        {errorMessage && (
          <div className="p-4 mb-6 bg-red-500/10 border border-red-500/20 text-red-600 dark:text-red-400 text-xs font-medium rounded-xl flex items-start gap-2 text-left max-w-sm mx-auto animate-in fade-in slide-in-from-top-1">
            <AlertCircle className="w-4 h-4 shrink-0 mt-0.5" />
            <span>{errorMessage}</span>
          </div>
        )}
        
        <div className="flex flex-col gap-4 max-w-sm mx-auto">
          <button 
            onClick={handleUnlock}
            disabled={unlocking}
            className={cn(
              "w-full flex items-center justify-center gap-2 py-4 font-bold text-white text-lg transition-all cursor-pointer",
              isBrutalist ? 'border-4 border-foreground shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] uppercase tracking-wider hover:translate-y-1 hover:shadow-none' : 'rounded-xl hover:opacity-90 active:scale-95'
            )}
            style={{ backgroundColor: accentColor || '#EE4B2B' }}
          >
            {unlocking ? (
              <Loader2 className="w-5 h-5 animate-spin" />
            ) : (
              <>
                <Wallet className="w-5 h-5" />
                Débloquer pour 2,00 €
              </>
            )}
          </button>

          {/* Show wallet balance if user is logged in */}
          {user && (
            <p className="text-xs text-muted-foreground font-mono">
              Solde actuel : {((user.walletBalanceCents || 0) / 100).toFixed(2)} €
            </p>
          )}

          <Link 
            href="#subscribe" 
            className={`w-full py-3 font-semibold text-foreground bg-neutral-100 hover:bg-neutral-200/80 dark:bg-zinc-800 dark:hover:bg-zinc-700/80 transition-all ${isBrutalist ? 'border-4 border-foreground shadow-[4px_4px_0px_0px_rgba(0,0,0,1)] uppercase tracking-wider hover:translate-y-1 hover:shadow-none' : 'rounded-xl'}`}
          >
            Voir les formules d'abonnement
          </Link>
          
          <p className="text-sm text-muted-foreground mt-2">
            {!user ? (
              <>
                Déjà abonné ?{" "}
                <button 
                  onClick={() => window.location.href = `${mainAppUrl}/login?redirect=${encodeURIComponent(window.location.href)}`} 
                  className="underline font-semibold hover:text-[var(--tenant-accent)] cursor-pointer bg-transparent border-0 p-0 text-foreground"
                >
                  Se connecter
                </button>
              </>
            ) : (
              <span>Connecté en tant que <strong className="text-foreground">{user.name || user.email}</strong></span>
            )}
          </p>
        </div>
      </div>
    </div>
  )
}
